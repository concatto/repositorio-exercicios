import MemberItem from './MemberItem';
import React from 'react';
export default [
{
name: "Elieser",
memberitem: <MemberItem name="Elieser" online={false}/>
},
{
name: "Magnani",
memberitem: <MemberItem name="Magnani" online={true}/>
}

]